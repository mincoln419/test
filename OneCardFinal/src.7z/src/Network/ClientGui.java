package Network;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import Main.PlayMode;
import Main.WaitingRoom;

public class ClientGui {

//	private JTextArea jta= new JTextArea(40,25);
//	private JTextField jtf= new JTextField(25);
//	public static Client client = new Client(client);
	
	
	public ClientGui(){
		
//		add(jta, BorderLayout.CENTER);
//		add(jtf, BorderLayout.SOUTH);
//		jtf.addActionListener(this);
		
//		setDefaultCloseOperation(EXIT_ON_CLOSE);
//		setVisible(true);
//		setBounds(800, 100, 400, 600);
//		setTitle("Ŭ���̾�Ʈ");
//		
//		client.setGui(this);
//		client.setId(PlayMode.idname);
//		client.connet();
//		
	}
	public static void main(String[] args) {
		
		
		
		new ClientGui();
	}
//	@Override
//	public void actionPerformed(ActionEvent e) {
////		String msg = id+" : "+jtf.getText()+"\n";
////		client.sendMsg(msg);
////		jtf.setText("");
//		
//	}
//	public void appendMsg(String msg) {
//		WaitingRoom.chat.setText(msg);
//
//	}

}
