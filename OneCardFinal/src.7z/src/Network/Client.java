package Network;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

import Main.PlayMode;
import Main.WaitingRoom;


public class Client implements Runnable{
	private Socket socket;
	static private DataInputStream din;
	static private DataOutputStream dout;	
	public  String msg;
	public String msg2;
	private String id;
	public Client client;	
	
	public Client(String idname){		
		this.id=idname;		
		setId(id);		
		connet();
		
	}	
	
	public void connet(){
		String ip="203.236.209.206";
		int port=7777;
		try {
			socket= new Socket(ip, port);
			
			System.out.println("��������");
			
			dout=new DataOutputStream(socket.getOutputStream());
			din =new DataInputStream(socket.getInputStream());
			
			dout.writeUTF(id);
			
			while(din!=null){
				msg=din.readUTF();
				WaitingRoom.chatt.append(msg);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	static public void sendMsg(String msg2) {
		try {
			dout.writeUTF(msg2);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void setId(String id) {
		this.id=id;
	}

	@Override
	public void run() {
		new Client(id);
		
	}
}
