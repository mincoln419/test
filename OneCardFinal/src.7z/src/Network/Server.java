package Network;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.ClientInfoStatus;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class Server {
	private ServerSocket serversocket;
	private Socket socket;
	private ServerGui gui;
	private String msg;
	private String id;
	
	private Map<String, DataOutputStream> clientsMap = new  HashMap<String, DataOutputStream>();
	
	
	public final void setGui(ServerGui gui){
		this.gui = gui;
	}
	
	public void setting(){
		int port=7777;
		
		try {
			Collections.synchronizedMap(clientsMap);
			serversocket = new ServerSocket(port);
			
			while(true){
				System.out.println("�����");
				socket=serversocket.accept();
				System.out.println(socket.getInetAddress()+"����");
				
				Receiver receiver = new Receiver(socket);
				receiver.start();
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		Server server=new Server();
		server.setting();
	}

	private void addClient(String id, DataOutputStream dout) {
		sendMsg(id+"�� ����"+"\n");
		clientsMap.put(id, dout);
	}
	
	public void removeClient(String id){
		sendMsg(id+"���� �����̽��ϴ�."+"\n");
		clientsMap.remove(id);
	}
	
	public void sendMsg(String msg) {
		Iterator<String> it = clientsMap .keySet().iterator();
		String key;
		while(it.hasNext()){
			try {
				key=it.next();
				clientsMap.get(key).writeUTF(msg);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	class Receiver extends Thread{
		
		private DataInputStream din;
		private DataOutputStream dout;
		
		public Receiver(Socket socket){
			try {
				dout=new DataOutputStream(socket.getOutputStream());
				din =new DataInputStream(socket.getInputStream());
				
				id= din.readUTF();
				addClient(id, dout);
				
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		@Override
		public void run() {
			try {
				while(din!=null){
					msg=din.readUTF();
					sendMsg(msg);
					gui.appendMsg(msg);
					 if(msg==null){
						 System.out.println("�̿����ּż� �����մϴ�");
						 break;}
				}
			} catch (IOException e) {
				removeClient(id);
			}
		}
	}
}
