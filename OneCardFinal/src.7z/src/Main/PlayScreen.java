package Main;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.Point;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.border.Border;

import Data.BattleRecord;
import Utility.OneColor;
import Utility.OneLabel;
import Utility.OneMenu;


class PlayThread implements Runnable{	
	String idname;
	PlayThread(String idname){
		this.idname=idname;
	}
	
	@Override
	public void run() {
	new PlayScreen(idname);
			
	}	
}

public class PlayScreen extends Frame implements ActionListener{
	
	GridBagLayout gb=new GridBagLayout();
	GridBagConstraints gbc=new GridBagConstraints();
	Dialog editor;
	String player1,player2,player3;
	public static int leftcardme=0;
	public static int leftcard1=7;
	public static int leftcard2=7;
	public static int leftcard3=7;
	String idname;
	TextArea chatta;
	TextField chattf;
	OneColor oc;
	Panel chat;
	Panel main;
		
	PlayScreen(String idname){		
		super("��� ��ī�� �÷���");		
		this.idname=idname;
		player1="��";
		player2="2";
		player3="4";
				
		Dimension res=Toolkit.getDefaultToolkit().getScreenSize();
		Font mainf=new Font("����", 1, 10);
		main=new Panel(gb);
		
		oc=new OneColor();
		
		panelLocation();
		
		Panel play1=new Panel(gb);
		play1.setBackground(oc.player1);		
		Panel play2=new Panel(gb);
		play2.setBackground(oc.player2);
		Panel play3=new Panel(gb);
		play3.setBackground(oc.player3);
		Panel me=new Panel();
		me.setBackground(oc.player4);
		Button oneCard=new Button("��ī��");
		oneCard.addActionListener(this);		
		gbc.fill=GridBagConstraints.BOTH;
		
		
		Panel center=new Panel(null);
		OneLabel centL=new OneLabel();
		center.setSize(50,50);
		center.add(centL.deck);
		centL.deck.setBounds(10, 20, 70,100);
		center.add(centL.center);
		centL.center.setBounds(90, 20, 70,100);
		addToFrame(1,1,1,1,1.0,1.0);
		main.add(center,gbc);
		
		addToFrame(1,0,1,1,1.0,1.0);
		OneLabel ol1=new OneLabel();
		play1.add(ol1.deck);
		main.add(play1,gbc);
		addToFrame(0,1,1,1,1.0,1.0);
		OneLabel ol2=new OneLabel();
		play2.add(ol2.deck);
		main.add(play2,gbc);
		addToFrame(2,1,1,1,1.0,1.0);
		OneLabel ol3=new OneLabel();
		play3.add(ol3.deck);
		main.add(play3,gbc);
		addToFrame(0,2,3,1,1.0,1.5);
		OneLabel olme=new OneLabel();
		me.setLayout(null);
		me.setSize(150,50);
		me.add(olme.card[1]);
		olme.card[1].setBounds(80, 10, 70,100);
		me.add(olme.card[2]);
		olme.card[2].setBounds(100, 10, 70,100);
		me.add(olme.card[3]);	
		olme.card[3].setBounds(120, 10, 70,100);
		me.add(oneCard);
		oneCard.setBounds(430, 10, 70,50);
		main.add(me,gbc);
		
		Panel chat=new Panel(gb);
		chatta=new TextArea(25,35);
		chatta.setEditable(false);
		
		chattf=new TextField(25);
		chattf.addActionListener(this);	
		JButton send=new JButton("����");
		send.addActionListener(this);
		setMenuBar(new OneMenu(idname));
		addToFrame(0,0,2,1,1.0,1.0);
		chat.add(chatta,gbc);
		gbc.fill=GridBagConstraints.BASELINE;
		addToFrame(0,1,1,1,1.0,1.0);
		chat.add(chattf,gbc);			
		addToFrame(1,1,1,1,1.0,1.0);
		chat.add(send,gbc);

		
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				// TODO Auto-generated method stub
				dispose();
			}
		});
		add(main,BorderLayout.CENTER);
		add(chat,BorderLayout.EAST);
		setBounds(res.width/4,res.height/4,800,500);
		setVisible(true);
		
	}
	
	private void panelLocation() {
		
	
		
	}
	private void addToFrame(int x,int y, int width, int height, double weightx, double weighty) {
		gbc.gridx=x;
		gbc.gridy=y;
		gbc.gridwidth=width;
		gbc.gridheight=height;
		gbc.weightx=weightx;
		gbc.weighty=weighty;
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		chatta.setText(chatta.getText()+chattf.getText()+"\r\n");
		chattf.setText("");
		if(e.getActionCommand()=="����"){
			leftcardme=0;
			chatta.setText(chatta.getText()+chattf.getText()+"\r\n");
			chattf.setText("");
			if(leftcardme==0){		//�ϴ� ������ ������ ������ ��������		
				String wl="�¸�";
				
				Thread thr3=new Thread(new BattleRecord(idname, player1, player2, player3,  wl));
				thr3.start();
				Thread thr1=new Thread(new WaitingRoom(idname));
				thr1.start();							
				dispose();
			}else if(leftcard1==0||leftcard2==0||leftcard3==0){
				
				String wl="�й�";
				Thread thr3=new Thread(new BattleRecord(idname, player1, player2, player3,  wl));
				thr3.start();
				Thread thr1=new Thread(new WaitingRoom(idname));
				thr1.start();				
				dispose();
			}		
			
		}
		
	}
	
	
}
