package Main;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Label;
import java.awt.Panel;
import java.awt.Point;
import java.awt.TextField;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.border.Border;
import javax.tools.DocumentationTool.Location;

import Network.ClientGui;


public class PlayMode extends Frame implements ActionListener{
	GridBagLayout gb=new GridBagLayout();
	GridBagConstraints gbc=new GridBagConstraints();
	Dialog editor;
	public static String idname;
	TextField id;
	static Thread thr1;
		
	PlayMode(){		
		super("�÷���-��� ��ī�� ver 1.0.0");
		
		Dimension res=Toolkit.getDefaultToolkit().getScreenSize();
		Font mainf=new Font("����", 1, 10);
			
		ImageIcon icon=new ImageIcon("./Image/MainImg.jpg");
		JLabel MainLabel=new JLabel(icon);	
		MainLabel.setBounds(100,0,100,100);		
		Label idl=new Label("����Ͻ� ���̵�",Label.RIGHT);			
		idl.setFont(mainf);
		Panel mainp=new Panel(gb);		
		Panel loginp=new Panel();
		Panel loginchkp=new Panel();
		JButton idchk=new JButton("�α���");
		idchk.addActionListener(this);		
		id=new TextField(30);		
		mainp.setLayout(new BorderLayout());		
		gbc.fill=GridBagConstraints.ABOVE_BASELINE;
		idname=id.getText();
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				// TODO Auto-generated method stub
				dispose();
			}
		});
		
		loginp.add(idl);		
		loginp.add(id);
		addtoframe(0,1,6,1,1.0,1.0);
		loginp.add(idchk,gbc);
		mainp.add(loginp);
		add(MainLabel,BorderLayout.NORTH);
		add(mainp,BorderLayout.CENTER);
		setBounds(res.width/4,res.height/4,800,500);
		setVisible(true);
		
	}
	private void addtoframe(int x,int y, int width, int height, double weightx, double weighty) {
		gbc.gridx=x;
		gbc.gridy=y;
		gbc.gridwidth=width;
		gbc.gridheight=height;
		gbc.weightx=weightx;
		gbc.weighty=weighty;
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		this.idname=id.getText();
		thr1=new Thread(new WaitingRoom(idname));//���Ƿ� �̵�
		thr1.start();
		dispose();
		
	}
	
	
}

