package Main;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Label;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;

import Network.Client;
import Network.ClientGui;
import Utility.OneMenu;


public class WaitingRoom extends Frame implements Runnable,ActionListener{
	GridBagLayout gb=new GridBagLayout();
	GridBagConstraints gbc=new GridBagConstraints();
	String idname;
	JButton ready;
	JButton cancle;
	public static String msg;
	public static TextField chat;
	public static TextArea chatt;
	static Thread thr2;
	Thread thr3;
	static Client client;
	
	public WaitingRoom(String idname) {
	super("���� - ��� ��ī�� ver 1.0.0");
	this.idname=idname;
	
	Dimension res=Toolkit.getDefaultToolkit().getScreenSize();
	
	Font mainf=new Font("����", 2, 10);
	Label idl=new Label("����Ͻ� ���̵�");
	idl.setFont(mainf);
	Panel mainp=new Panel();
	Panel chatp=new Panel(gb);
	Panel gamestart=new Panel(gb);
			
	JButton send=new JButton("����");
	ready=new JButton("    �غ�     ");
	cancle=new JButton("�غ�����");
	cancle.setEnabled(false);
	chat=new TextField(60);
	chatt=new TextArea("������� ��ī���Դϴ�\r\n",30,30);//ä��â
	TextArea member=new TextArea(30,30);//ä�ù濡 �ִ� ��� ����
	member.setEditable(false);
	ready.addActionListener(this);
	cancle.addActionListener(this);
	
	send.addActionListener(this);//���۹�ư�� ���Ϳ� �޽��� �Է� ���Ǹ�����
	chat.addActionListener(this);
	mainp.setLayout(new BorderLayout());
	chatp.setLayout(gb);
		
	addtoframe(0,0,1,1,1.0,1.0);	
	gamestart.add(member, gbc);
	addtoframe(0,1,1,1,1.0,1.0);	
	gamestart.add(ready, gbc);		
	addtoframe(0,2,1,1,1.0,1.0);
	gamestart.add(cancle, gbc);
	
	gbc.fill=GridBagConstraints.BOTH;	
	addtoframe(0,0,4,1,1.0,1.0);	
	chatp.add(chatt, gbc);
	gbc.fill=GridBagConstraints.BASELINE;
	addtoframe(0,1,3,1,1.0,1.0);	
	chatp.add(chat, gbc);
	addtoframe(3,1,1,1,1.0,1.0);	
	chatp.add(send, gbc);
	
	mainp.add(chatp,BorderLayout.CENTER);
	mainp.add(gamestart,BorderLayout.EAST);	
	
	addWindowListener(new WindowAdapter() {
		@Override
		public void windowClosing(WindowEvent e) {
			// TODO Auto-generated method stub			
			dispose();
		}
	});	
	
	setMenuBar(new OneMenu(idname));
	add(mainp);
	setBounds(res.width/4,res.height/4,800,600);
	setVisible(true);
		
	}	
		
	@Override
	public void run() {	
		client=new Client(idname);
		Thread thr2=new Thread(client);//�������			
		thr2.start();			
			
		}
			
	
	private void addtoframe(int x,int y, int width, int height, double weightx, double weighty) {
		gbc.gridx=x;
		gbc.gridy=y;
		gbc.gridwidth=width;
		gbc.gridheight=height;
		gbc.weightx=weightx;
		gbc.weighty=weighty;
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand()=="    �غ�     ") {
			cancle.setEnabled(true);			
			ready.setEnabled(false);			
			thr3=new Thread(new PlayThread(idname));//������ �ݺ���Ű�� ���� ������
			thr3.start();			
			dispose();
		}else if(e.getActionCommand()=="�غ�����") {
			cancle.setEnabled(false);
			ready.setEnabled(true);
		}else{			
			msg = idname+" : "+chat.getText()+"\r\n";			
			Client.sendMsg(msg);	
			chat.setText("");		
			}
		
	
	}


}
