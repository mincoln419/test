package Utility;

import java.awt.Color;

public class OneColor {
	public Color board;
	public Color player1;
	public Color player2;
	public Color player3;
	public Color player4;
	public Color chat;
	
	
	public OneColor(){
		board=new Color(0,150,150);
		player1=new Color(100,250,150);
		player2=new Color(100,150,150);
		player3=new Color(100,250,150);
		player4=new Color(200,250,100);
		chat=new Color(100,150,250);
	
	}
	
}
