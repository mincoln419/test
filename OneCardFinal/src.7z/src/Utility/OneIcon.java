package Utility;

import java.awt.Image;

import javax.swing.Icon;
import javax.swing.ImageIcon;

public class OneIcon {
	public ImageIcon[] icon=new ImageIcon[54];
	public Image tmp;
	
	public OneIcon(){		
		for(int i=0;i<4;i++) {
			for(int j=0;j<13;j++) {
	icon[i]=new ImageIcon("./Image/"+i+"_"+j+".png");		
	tmp	= icon[i].getImage();  //ImageIcon�� Image�� ��ȯ.
	tmp = tmp.getScaledInstance(70,100, java.awt.Image.SCALE_SMOOTH);
	icon[i]=new ImageIcon(tmp); //Image�� ImageIcon ����	
			}
		}
	}
}
