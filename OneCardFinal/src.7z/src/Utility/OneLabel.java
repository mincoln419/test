package Utility;

import java.awt.Image;
import java.awt.Label;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class OneLabel {
	public JLabel[] card=new JLabel[54];
	
	public JLabel deck;
	public JLabel center;
	public OneLabel(){
		ImageIcon icon=new ImageIcon("./Image/back_up.png");
		Image icon2 = icon.getImage();  //ImageIcon�� Image�� ��ȯ.
		icon2 = icon2.getScaledInstance(70,100, java.awt.Image.SCALE_SMOOTH);
		icon=new ImageIcon(icon2); //Image�� ImageIcon ����	
		deck=new JLabel(icon);
		
		
		OneIcon oi=new OneIcon();		
		card[1]=new JLabel(oi.icon[1]);
		card[2]=new JLabel(oi.icon[2]);
		card[3]=new JLabel(oi.icon[3]);
		
		
		center=new JLabel(oi.icon[1]);//�ϴ� ���÷� �Ѱ��̰�, ���⿡ ����ī�尡 �پ����
		
		
	}
	
	
}
